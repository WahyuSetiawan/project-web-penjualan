<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_gambar_produk extends CI_Migration
{
    public $table = "tbl_gambar_produk";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_gambar_produk' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                ),
                'id_produk' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'path' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'CONSTRAINT FOREIGN KEY (id_produk) REFERENCES tbl_produk(id_produk)'
            )
        );

        $this->dbforge->add_key('id_gambar_produk', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file gambar_produk.php */
