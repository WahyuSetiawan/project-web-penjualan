<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_detail_pesan extends CI_Migration
{
    public $table = 'tbl_detail_pesan';

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {

        $this->dbforge->add_field(
            array(
                'id_detail_pesan' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                ),
                'id_pesanan' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'id_produk' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'qty' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'catatan_produk' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id_detail_pesan', true);
        $this->dbforge->create_table($this->table);

    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file detail_pesan.php */
