<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_produk_image extends CI_Migration
{
    public $table = "tbl_produk_image";
    
    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                    'auto_increment' => true,
                ),
                'id_produk' => array(
                    'type' => "INT",
                    'constraint' => 11,
                ),
                'image' => array(
                    'type' => "varchar",
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file produk_image.php */
