<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_produk extends CI_Migration
{
    public $table = 'tbl_produk';

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_produk' => array(
                    'type' => "INT",
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                ),
                'nama_produk' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'id_kategori' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'stok_produk' => array(
                    'type' => 'ENUM("Tersedia", "Kosong")',
                    "null" => false
                ),
                'deskripsi_produk' => array(
                    'type' => 'text',
                ),
                'harga_produk' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'gambar_1' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'gambar_2' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'gambar_3' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'gambar_4' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id_produk', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);

    }

}

/* End of file produk.php */
