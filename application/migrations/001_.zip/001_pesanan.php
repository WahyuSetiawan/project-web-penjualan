<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_pesanan extends CI_Migration
{
    public $table = "tbl_pesanan";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_pesanan' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'id_konsumen' => array(
                    'type' => "INT",
                    'constraint' => 11,
                    'null' => false,
                ),
                'nama_penerima' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'no_hp_penerima' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'provinsi_penerima' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'kota_penerima' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'kode_pos' => array(
                    'type' => 'char',
                    'constraint' => 200,
                ),
                'alamat' => array(
                    'type' => 'text',
                    'null' => false,
                ),
                'jumlah_ongkir' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'jumlah_pesan' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'total_bayar' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'kode_unix' => array(
                    'type' => "INT",
                    'constraint' => 11,
                    'null' => false,
                ),
                'tanggal_pesan' => array(
                    'type' => 'date',
                    'null' => false,
                ),
                'status_pesanan' => array(
                    'type' => 'enum("Menunggu", "Konfirmasi", "Dikonfirmasi")',
                    'default' => "Menunggu",
                ),
                'kurir' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'id_bank' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                ),
                'bukti_transfer' => array(
                    'type' => "text",
                ),
                'resi_pengirimman' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id_pesanan', true);

        $this->dbforge->create_table($this->table, true);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->tables);

    }

}

/* End of file pesanan.php */
