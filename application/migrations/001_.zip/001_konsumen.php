<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_konsumen extends CI_Migration
{
    public $table = "tbl_konsumen";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_konsumen' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                    'unique' => true
                ),
                'nama_konsumen' => array(
                    'type' => "varchar",
                    'constraint' => 200,
                    'null' => false,
                ),
                'email_konsumen' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'password_konsumen' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'no_hp_konsumen' => array(
                    'type' => "varchar",
                    'constraint' => 200,
                ),
                'tmp_forgot_password' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'unique' => true
                ),
            )
        );

        $this->dbforge->add_key('id_konsumen', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file konsumen.php */
