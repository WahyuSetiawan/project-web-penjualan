<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_carousell extends CI_Migration
{

    public $table = 'tbl_carousell';

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_carousell' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                ),
                'sub_title' => array(
                    'type' => 'varchar',
                    'constraint' => 50,
                    'null' => false,
                    'default' => "0",
                ),
                'title' => array(
                    'type' => 'varchar',
                    'constraint' => '50',
                ),
                'content' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
                'img' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id_carousell', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file carousell.php */
