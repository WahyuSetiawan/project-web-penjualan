<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_settings extends CI_Migration
{
    public $table = "tbl_settings";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id' => array(
                    'type' => "INT",
                    'constraint' => 11,
                    'null' => false,
                    'auto_increment' => true,
                ),
                'setting' => array(
                    'type' => "varchar",
                    'constraint' => 20,
                    'null' => false,
                ),
                'value' => array(
                    'type' => 'text',
                ),
            )
        );

        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file settings.php */
