<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_pembelian extends CI_Migration
{
    public $table = "tbl_pembelian";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_pembelian' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                    'auto_increment' => true,
                ),
                'id_supplier' => array(
                    'type' => "INT",
                    'constraint' => 11,
                    'null' => false,
                ),
                'id_produk' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'jumlah' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'nominal' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ),
                'tanggal' => array(
                    'type' => datetime,
                ),
                "`created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,",
                "`updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,",
                "CONSTRAINT `FK_tbl_pembelian_tbl_produk` FOREIGN KEY (`id_produk`) REFERENCES `tbl_produk` (`id_produk`) ON UPDATE CASCADE,",
                "CONSTRAINT `FK_tbl_pembelian_tbl_supplier` FOREIGN KEY (`id_supplier`) REFERENCES `tbl_supplier` (`id_supplier`) ON UPDATE CASCADE",
            )
        );

        $this->dbforge->add_key('id_pembelian', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file pembelian.php */
