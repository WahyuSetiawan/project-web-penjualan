<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Class_name extends CI_Migration
{
    public $table = "tbl_produk_kategori";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_kategori' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => true,
                    'null' => false,
                ),
                'nama_kategori' => array(
                    'type' => 'VARCHAR',
                    'constraint' => 200,
                ),
            )
        );

        $this->dbforge->add_key('id_kategori', true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file Class_name.php */
