<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_supplier extends CI_Migration
{
    public $table = "tbl_supplier";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                'id_supplier' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                    'auto_increment' => true,
                ),
                'nama' => array(
                    'type' => 'varchar',
                    'constraint' => 50,
                    'null' => false,
                ),
                'alamat' => array(
                    'type' => 'varchar',
                    'constraint' => 200,
                    'null' => false,
                ),
                'telepon' => array(
                    'type' => 'varchar',
                    'constraint' => 50,
                ),
            )
        );

        $this->dbforge->add_key("id_supplier", true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->drop_table($this->table);
    }

}

/* End of file supplier.php */
