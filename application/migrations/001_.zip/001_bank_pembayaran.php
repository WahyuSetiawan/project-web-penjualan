<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Migration_bank_pembayaran extends CI_Migration
{
    public $table = "tbl_bank_pembayaran";

    public function __construct()
    {
        $this->load->dbforge();
        $this->load->database();
    }

    public function up()
    {
        $this->dbforge->add_field(
            array(
                "id_bank" => array(
                    "type" => "INT",
                    'constraint' => 11,
                    'auto_increment' => true,
                ),
                'nama_bank' => array(
                    'type' => 'varchar',
                    'constraint' => '200',
                ),
                'atas_nama' => array(
                    'type' => 'INT',
                    'constraint' => 200,
                ),
                'no_rekening' => array(
                    'type' => 11,
                    'constraint' => 11,
                    'null' => false,
                ),
            )
        );

        $this->dbforge->add_key("id_bank", true);
        $this->dbforge->create_table($this->table);
    }

    public function down()
    {
        $this->dbforge->forge_table($this->table);
    }

}

/* End of file bank_pembayaran php */
